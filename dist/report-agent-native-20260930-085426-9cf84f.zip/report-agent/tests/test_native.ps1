﻿# Run with Windows PowerShell 5.1. No Python, Pester or Office required.
param([switch]$Live)
$ErrorActionPreference='Stop'
. "$PSScriptRoot/../src/native/Environment.ps1"
. "$PSScriptRoot/../src/native/Main.ps1"
. "$PSScriptRoot/../src/native/Maintenance.ps1"
$originalRoot=$script:Root
$testRoot=Join-Path $originalRoot ('tmp/staging/native-tests-'+[guid]::NewGuid().ToString('N'))
[void][IO.Directory]::CreateDirectory($testRoot)
$manifest=Read-Json (Join-Path $originalRoot 'config/agent_integrity.json')
foreach ($relative in @($manifest.files.Keys)+@('config/agent_integrity.json','README.md')) {
    $dest=Join-Path $testRoot $relative; [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($dest)); [IO.File]::Copy((Join-Path $originalRoot $relative),$dest)
}
$script:Root=$testRoot
$passed=0
function Assert($Condition,$Label) { if (-not $Condition) {throw "FAIL: $Label"}; $script:passed++; Write-Output "PASS: $Label" }
function Must-Fail([scriptblock]$Action,$Label) { $failed=$false; try { & $Action | Out-Null } catch {$failed=$true}; Assert $failed $Label }
Must-Fail {Assert-SupportedHost ([PlatformID]::Unix) ([version]'7.4') $true} 'non-Windows rejected'
Must-Fail {Assert-SupportedHost ([PlatformID]::Win32NT) ([version]'5.0') $true} 'old PowerShell rejected'
Must-Fail {Assert-SupportedHost ([PlatformID]::Win32NT) ([version]'5.1') $false} 'missing worker rejected'
Assert-SupportedHost ([PlatformID]::Win32NT) ([version]'5.1') $true
Assert $true 'Windows PowerShell 5.1 accepted'
Invoke-Native @('start','--topic','原生自动化验证报告','--date','20990101') | Out-Null
$sp=Join-Path $testRoot 'dir/20990101/workflow_state.json'
Assert ((Read-Json $sp).status -eq 'T1_OUTLINE_REQUIRED') 'start state'
Must-Fail {Invoke-Native @('choose-code','--state',$sp,'--mode','none','--confirm')} 'cannot bypass gate1'
$outline="# 原生测试大纲`n## 环境能力验证`n- 验证环境。`n### 原生文件构建`n- 验证构建。`n## 文档结构验证`n- 验证结构。`n### 目录页码验证`n- 验证目录。"
$draft=Join-Path ([IO.Path]::GetDirectoryName($sp)) 'outline.draft.md'; [IO.File]::WriteAllText($draft,$outline,$script:Utf8)
Invoke-Native @('save-outline','--state',$sp,'--source',$draft) | Out-Null
Must-Fail {Invoke-Native @('approve-outline','--state',$sp,'--pages','1')} 'gate1 requires confirmation'
Invoke-Native @('approve-outline','--state',$sp,'--pages','1','--confirm') | Out-Null
Invoke-Native @('choose-code','--state',$sp,'--mode','none','--confirm') | Out-Null
Invoke-Native @('prepare-content','--state',$sp) | Out-Null
$input=Join-Path ([IO.Path]::GetDirectoryName($sp)) 'report_content.json'
Must-Fail {Invoke-Native @('prepare-content','--state',$sp)} 'content not overwritten'
Must-Fail {Invoke-Native @('generate','--workflow-state',$sp,'--input',$input,'--output','test.docx','--check-only')} 'placeholder rejected'
$data=Read-Json $input; $data.project_name='原生测试项目'
foreach ($s in $data.sections) { $s.paragraphs=@('用于测试原生文档构建。'); foreach ($sub in $s.subsections) {$sub.paragraphs=@('用于测试二级标题和目录关联。')} }
Write-Json $input $data
Invoke-Native @('generate','--workflow-state',$sp,'--input',$input,'--output','test.docx','--check-only') | Out-Null
Assert ((Read-Json $sp).status -eq 'T2_READY') 'precheck does not advance gate'
$pending=Join-Path $testRoot 'test.pending.docx'; Build-Document $data $pending $null
$zip=[IO.Compression.ZipFile]::OpenRead($pending)
try { $xml=Read-SafeXml (Read-ZipText $zip 'word/document.xml'); $text=$xml.OuterXml; Assert ($text.Contains('1. 环境能力验证') -and $text.Contains('一、环境能力验证')) 'distinct TOC/body numbering'; Assert ($text.Contains('1.1 原生文件构建')) 'subheadings present' } finally {$zip.Dispose()}
$map=@{status='ok';body_pages=1;pages=5;toc_start_physical_page=4;toc_end_physical_page=4;body_start_physical_page=5;page_map=@()}
foreach ($h in (Get-Headings $data)) {$map.page_map+=@{bookmark=$h.bookmark;toc_page=1;body_footer_page=1}}
Must-Fail {Test-SavedDocument $pending $map $data} 'unrefreshed cached page rejected'
if ($Live) {
    $liveDir=Join-Path $testRoot 'live'; [void][IO.Directory]::CreateDirectory($liveDir)
    $liveData=Read-Json (Join-Path $originalRoot 'dir/20260930/report_content.json')
    $template=Join-Path $originalRoot 'samples/school_templates/成绩单、封面和撰写要求样本1.docx'
    if (-not (Test-Path $template)) {$template=$null}
    $liveDoc=Join-Path $liveDir 'test.pending.docx'; Build-Document $liveData $liveDoc $template
    $engines=Get-Renderers; if (-not $engines.Count) {throw 'Live test requires a registered engine.'}
    $liveMap=Invoke-Renderer $liveDoc (Join-Path $liveDir 'diagnostics') $engines[0] 90
    Test-SavedDocument $liveDoc $liveMap $liveData
    Assert ($liveMap.body_pages -gt 1) 'live multipage template TOC/footer and fonts'
    Write-Output ($liveMap | ConvertTo-Json -Depth 8 -Compress)
}
# Mock rendering only in this isolated test copy; never touch live task receipts.
function Select-Renderer($State,$StatePath,$Requested) { return @{engine='test-mock';prog_id='test'} }
function Invoke-Renderer($Document,$Directory,$Engine,$Timeout) {
    $z=[IO.Compression.ZipFile]::Open($Document,[IO.Compression.ZipArchiveMode]::Update)
    try { $body=Read-ZipText $z 'word/document.xml'; $body=$body.Replace('>0</w:t>','>1</w:t>'); Write-ZipText $z 'word/document.xml' $body } finally {$z.Dispose()}
    return $map
}
Invoke-Native @('generate','--workflow-state',$sp,'--input',$input,'--output','test.docx') | Out-Null
Assert ((Read-Json $sp).status -eq 'GATE3_WAITING_APPROVAL') 'mock render enters gate3 only'
Must-Fail {Invoke-Native @('finish','--state',$sp,'--output','final.docx','--confirm')} 'cannot bypass gate3/4'
Invoke-Native @('generate','--workflow-state',$sp,'--input',$input,'--output','test.docx') | Out-Null
Assert ((Read-Json $sp).status -eq 'GATE3_WAITING_APPROVAL') 'verified reuse retains gate'
Invoke-Native @('review-decision','--state',$sp,'--approve','--confirm') | Out-Null
Invoke-Native @('final-check','--state',$sp) | Out-Null
Must-Fail {Invoke-Native @('finish','--state',$sp,'--output','final.docx')} 'gate4 requires confirmation'
Invoke-Native @('finish','--state',$sp,'--output','final.docx','--confirm') | Out-Null
Assert ((Read-Json $sp).status -eq 'COMPLETE') 'mock full workflow completion'
$state=Read-Json $sp; $receipt=Project-Path $state.review.receipt; $tampered=Read-Json $receipt; $tampered.body_pages=99; Write-Json $receipt $tampered
Must-Fail {Check-Review $state $sp} 'receipt tampering rejected'
Must-Fail {Project-Path '../outside.docx'} 'path escape rejected'
Write-Output "Native tests passed: $passed. Workflow Office calls mocked; optional Live=$Live used real Office. Artifacts: $testRoot"
