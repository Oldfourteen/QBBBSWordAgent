﻿function Get-Renderers {
    $list=@()
    foreach ($item in @(@('word','Word.Application'),@('wps','KWPS.Application'),@('wps','WPS.Application'))) {
        if ([type]::GetTypeFromProgID($item[1])) { $list+=@{engine=$item[0];prog_id=$item[1]} }
    }
    return ,$list
}
function Invoke-Renderer($Document,$Directory,$Engine,$Timeout=90) {
    [void][IO.Directory]::CreateDirectory($Directory)
    $trace=Join-Path $Directory 'trace.json'; $stdout=Join-Path $Directory 'stdout.txt'; $stderr=Join-Path $Directory 'stderr.txt'
    $worker=Join-Path $script:Root 'scripts/refresh_word_fields.ps1'
    $command=@('-NoProfile','-NonInteractive','-File',('"'+$worker+'"'),'-DocumentPath',('"'+$Document+'"'),'-TracePath',('"'+$trace+'"'),'-ProgId',$Engine.prog_id)
    $process=Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $command -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
    $processHandle=$process.Handle # Keep the native handle alive so PS5.1 retains ExitCode.
    $finished=$process.WaitForExit($Timeout*1000)
    if (-not $finished) { Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue }
    $process.Refresh()
    if (-not $finished -or $process.ExitCode -ne 0) {
        $detail=if (Test-Path $stderr) { Get-Content $stderr -Raw -Encoding UTF8 } else { '' }
        $stage=if (Test-Path $trace) { (Read-Json $trace).stage } else { 'worker_start' }
        if (Test-Path $trace) {
            $identity=Read-Json $trace
            if ($identity.owned) {
                try { & (Join-Path $script:Root 'scripts/cleanup_owned_word.ps1') -TracePath $trace | Out-Null }
                catch { $detail+="`nOwned-process cleanup refused: $($_.Exception.Message)" }
            }
        }
        throw "Renderer failed ($($Engine.engine)), stage=$stage, timeout=$(-not $finished). $detail Diagnostics: $Directory. Request the host client's legitimate execution approval if access was denied; do not ask the user to copy terminal commands or retry blindly."
    }
    $lines=@(Get-Content $stdout -Encoding UTF8 | Where-Object {$_.Trim()})
    if (-not $lines.Count) { throw 'Renderer did not return a page map.' }
    return (ConvertTo-Map ($lines[-1] | ConvertFrom-Json))
}
function Select-Renderer($State,$StatePath,$Requested='auto') {
    $available=Get-Renderers
    if ($State.renderer) {
        if ($Requested -ne 'auto' -and $Requested -ne $State.renderer.engine) { throw 'Renderer pinned for this task; do not silently change pagination engines.' }
        if (-not @($available | Where-Object {$_.prog_id -eq $State.renderer.prog_id}).Count) { throw 'Pinned renderer unavailable.' }
        return $State.renderer
    }
    if ($Requested -ne 'auto') { $available=@($available | Where-Object {$_.engine -eq $Requested}) }
    if (-not $available.Count) { throw 'No registered Word/WPS automation engine. Installation alone does not prove automation support.' }
    $folder=Reserve-Directory (Join-Path $script:Root 'tmp/staging') ('native-probe-'+[guid]::NewGuid().ToString('N'))
    $data=@{report_title='排版能力验证报告';code_block_mode='none';sections=@(@{title='环境功能检查';paragraphs=@('验证打开与保存。');subsections=@(@{title='页码功能检查';paragraphs=@('验证目录与页码。')})},@{title='排版结果检查';paragraphs=@('验证正文结构。');subsections=@(@{title='最终保存检查';paragraphs=@('验证最终结果。')})})}
    $failures=@()
    foreach ($candidate in $available) {
        $path=Join-Path $folder ($candidate.prog_id+'.pending.docx')
        Build-Document $data $path $null
        try {
            $map=Invoke-Renderer $path (Join-Path $folder $candidate.prog_id) $candidate 45
            Test-SavedDocument $path $map $data
            $candidate.verified_at=[DateTimeOffset]::Now.ToString('o')
            $State.renderer=$candidate; Save-State $StatePath $State 'renderer_capability_verified'
            return $candidate
        } catch {
            $failures+= $_.Exception.Message
            # Stop on the first failed live probe: a hung desktop process must be diagnosed before launching another engine.
            break
        }
    }
    throw ($failures -join "`n")
}
