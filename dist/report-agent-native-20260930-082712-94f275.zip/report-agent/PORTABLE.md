# Windows 原生便携版
支持范围：Windows 10/11、Windows PowerShell 5.1、可正常自动化的桌面 Word 或 WPS。运行无需 Python，无需 pip，无需某家 Agent 的运行库。旧 Python 文件已退役清理。

## 接入
把整个分发包解压到可写目录，让有本地文件和命令能力的 Agent 读取 AGENTS.md、agents/system_prompt.md、workflow/WORKFLOW.md 和本文件。首条报告回复必须展示固定工作流图和完整步骤表。调用 agent.ps1；所有命令由 Agent 执行，用户只确认原有四道闸门及必要的客户端权限请求。

## 自动执行与引擎
默认 --engine auto：检测 Word.Application、KWPS.Application、WPS.Application。优先 Word，无 Word 注册时选择 WPS。首次对独立文档进行限时真实打开、分页、保存及目录校验，通过后记录任务引擎；后续不静默换引擎。已注册引擎探测失败时先停止诊断，不在可能挂起的会话里连续启动多个引擎；解决后可在尚未锁定的任务显式选择 --engine wps。
WPS适配走兼容自动化接口，不保证所有WPS版本或版本授权具备这些接口。只有通过真实探测才视为可用。本机未检测到WPS注册，因此WPS实机兼容仍待验证。

不再默认提交排版任务让用户手动操作终端。权限明确拒绝时，Agent应使用宿主客户端正式的授权执行能力请求许可；没有该能力就如实报告阻塞，不能绕过沙箱。手动Word正常而Agent失败时，应对比执行账户、临时目录、缓存目录及权限，不直接重装Office。

## 诊断
agent.ps1 doctor 为只读依赖检查；doctor --probe 为限时实际排版探测。generate的失败记录在任务 last_generation.json，阶段诊断在 tmp/staging/native-*/diagnostics 或 native-probe-*。不自动修改注册表、永久环境变量、ACL，不关闭用户已有Office，不盲目加超时。
“无法创建工作文件”不能仅凭错误文本归因于TEMP。需核对错误进程的TEMP/TMP、用户配置、INetCache/Content.Word的写入权限。当前不自动执行系统级修复。
首次探测失败也不会推进闸门。旧桌面队列完整保留；改用原任务和原输入执行 generate，不直接复用未经校验的旧结果。

## 模板与输出
内置三页简单占位样板。默认优先使用 samples/school_templates/成绩单、封面和撰写要求样本1.docx，也可指定 --school-template。原生模板支持单节的三页DOCX；多节模板明确拒绝，不静默丢弃学校模板。分页会验证目录从物理第4页开始。
正式输出为DOCX。暂不提供原生旧式DOC转换或显式附录；不会以改扩展名伪造DOC。默认无附录。
报告和目录页码以本任务锁定引擎为准；在不同软件重新打开导致重排时须重新验证，不承诺跨引擎分页完全一样。

## 分发与安全
agent.ps1 package 白名单打包程序、规则、模板骨架和说明，不包含历史任务、真实学校模板和私人训练报告。全部路径按解压目录计算。
agent.ps1 clean 先展示计划，用户授权后再 clean --apply。目前仅允许清理14天前的stdout/stderr诊断日志；不清理报告、样本或任务状态。
完整性哈希用来检测意外修改，不是密码学授权机制，也不能代替OS权限。生成时禁止AI自行修改程序或伪造确认。
