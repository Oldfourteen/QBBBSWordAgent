# 期末大作业报告生成器：原生PowerShell迁移版
面向Windows 10/11本地Agent，运行入口为agent.ps1；无需Python或pip。Word/WPS自动检测，首次实测通过后锁定任务引擎。固定流程位于workflow/WORKFLOW.md，四道用户确认保持不变。

## 使用
将项目目录交给有本地文件及命令执行能力的Agent，要求读取AGENTS.md、agents/system_prompt.md、workflow/WORKFLOW.md和PORTABLE.md。AI负责执行命令；用户确认大纲与页数、代码方式、待审稿和最终稿。必要权限通过Agent客户端的正式授权机制申请，不默认让用户手动执行终端命令。

命令详见workflow/COMMANDS.md。doctor检查环境，doctor --probe实测排版，generate自动执行构建、排版和校验，package生成不含私人报告的便携包。

## 目录
- src/native：固定的原生状态机、内容校验、Open XML构建、Office运行时和维护命令。
- scripts/refresh_word_fields.ps1：Word/WPS共享的兼容接口分页及目录页码校验。
- workflow：固定工作流及命令参数。
- agents、config：提示词、约束及完整性清单。
- dir/YYYYMMDD[_NN]：大纲、内容、状态、待审稿。
- output/YYYYMMDD[_NN]：闸门4批准后的最终报告。
- samples：学校模板、参考内容和错误样本，均保留。
- tmp/staging：未发布文档及诊断。
- dist：便携包。
旧Python实现已退役清理，原生运行链不依赖Python。

## 版式与验收
正文一级标题使用中文序号，目录一级标题为1.、2.；二级标题为1.1等。目录逐项绑定书签和PAGEREF，核对排版引擎实际页码及保存后的域结果。正文从目录后下一页开始，页脚从1开始。默认无附录，字数不限，以用户确认的正文页数为准。
不通过页数、目录或完整性检查时不得进入闸门3或发布。

## 当前边界
Windows原生迁移需要真实Office验收；存在自动化注册不等于可用。WPS接口因版本而异，实机探测未通过不得宣称兼容。具体环境状态见本次维护交付说明。
学校模板目前支持单节三页DOCX；多节模板明确拒绝，源文件不改。原生输出DOCX，旧式DOC导出及显式附录暂不提供。不修改系统注册表、永久环境变量或Office安装，不关闭用户已有会话。
详见PORTABLE.md。
